import uuid
nothign = uuid.uuid4()
print(nothign)
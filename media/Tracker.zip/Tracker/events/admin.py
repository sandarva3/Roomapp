from django.contrib import admin
from .models import Event, Eventitems

admin.site.register(Event)
admin.site.register(Eventitems)


